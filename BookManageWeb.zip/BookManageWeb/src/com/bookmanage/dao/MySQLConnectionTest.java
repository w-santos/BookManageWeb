package com.bookmanage.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

public class MySQLConnectionTest {
	
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException ex) {
		}
	}
	
  public static void main(String[] args) {
    Connection con = null;

    String jdbcURL = "jdbc:mysql://localhost:3306/booklib?useSSL=false";
    String jdbcUsername = "root";
    String jdbcPassword = "swordfish";


    
    try {
      //Class.forName("com.mysql.jdbc.Driver");
      con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

      System.out.println("Connected!");

    } catch (SQLException ex) {
        throw new Error("Error ", ex);
    } finally {
      try {
        if (con != null) {
            con.close();
        }
      } catch (SQLException ex) {
          System.out.println(ex.getMessage());
      }
    }
  }
}