package com.bookmanage.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bookmanage.model.*;

public class BookDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/booklib?useSSL=false&allowPublicKeyRetrieval=true";
    private String jdbcUsername = "root";
    private String jdbcPassword = "swordfish";
    
    private static final String INSERT_BOOK_SQL = "insert into books"+ " (book_title, author_name, genre) values " + "(?,?,?);";
    
    private static final String SELECT_BOOK_BY_ID = "select " + " book_title, author_name, genre " + " from books " + "where id = ?;";
    private static final String SELECT_ALL_BOOKS = "select " + " id, book_title, author_name, genre " + " from books;";
    
    private static final String DELETE_BOOK_BY_ID = "delete " + "from books " + "where id = ?;";	
    
    private static final String UPDATE_BOOK_SQL = "update " + "books " + "set " + "book_title = ?, " + "author_name = ?, " + "genre = ? " + "where id = ?;";
    
    public BookDAO() {
    	
    }
    
    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }
    
	private void closeConnection(Connection connection) {
		if (connection == null)
			return;
		try {
			connection.close();
		} catch (SQLException ex) {
		}
	}
	
    public void insertBook(Book book) throws SQLException {
    	
        System.out.println(INSERT_BOOK_SQL);
        
        Connection connection = getConnection();
        
        try {
        	
        	PreparedStatement preparedStatement = connection.prepareStatement(INSERT_BOOK_SQL);
        	
            preparedStatement.setString(1, book.getBook_title());
            preparedStatement.setString(2, book.getAuthor_name());
            preparedStatement.setString(3, book.getGenre());
            
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
		} finally {
			closeConnection(connection);
		}
    }
    
    public Book selectBook(int id) {
        Book book = null;

        Connection connection = getConnection();
        
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BOOK_BY_ID);
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String book_title = rs.getString("book_title");
                String author_name = rs.getString("author_name");
                String genre = rs.getString("genre");
                book = new Book(id, book_title, author_name, genre);
            }
        } catch (SQLException e) {
            printSQLException(e);
		} finally {
			closeConnection(connection);
		}
        return book;
    }

    public List<Book> selectAllBooks() {
    	
        List<Book> books = new ArrayList<>();
        
        Connection connection = getConnection();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_BOOKS);
            
        	System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String book_title = rs.getString("book_title");
                String author_name = rs.getString("author_name");
                String genre = rs.getString("genre");
                books.add(new Book(id, book_title, author_name, genre));
            }
        } catch (SQLException e) {
            printSQLException(e);
		} finally {
			closeConnection(connection);
		}
        return books;
    }
    
    public boolean deleteBook(int id) throws SQLException {
    	
    	boolean rowDeleted;
    	
    	Connection connection = getConnection(); 
        
    	try {
    		PreparedStatement statement = connection.prepareStatement(DELETE_BOOK_BY_ID);
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
		} finally {
			closeConnection(connection);
		}
    	return rowDeleted;
    }
    
    public boolean updateBook(Book book) throws SQLException {
    	
    	boolean rowUpdated;
    	
    	Connection connection = getConnection();
    	
        try {
        	PreparedStatement statement = connection.prepareStatement(UPDATE_BOOK_SQL);
            
        	statement.setString(1, book.getBook_title());
        	statement.setString(2, book.getAuthor_name());
        	statement.setString(3, book.getGenre());
            statement.setInt(4, book.getId());

            rowUpdated = statement.executeUpdate() > 0;
		} finally {
			closeConnection(connection);
		}
    	return rowUpdated;
    }
    
    
    private void printSQLException(SQLException ex) {
    	
        for (Throwable e: ex) {
        	
            if (e instanceof SQLException) {
            	
                e.printStackTrace(System.err);
                
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                
                Throwable t = ex.getCause();
                
                while (t != null) {
                	
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                    
                }
            }
        }
    }
}
