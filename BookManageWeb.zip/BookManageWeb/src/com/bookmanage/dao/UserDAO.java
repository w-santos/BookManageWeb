package com.bookmanage.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bookmanage.model.*;

public class UserDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/booklib?useSSL=false";
    private String jdbcUsername = "root";
    private String jdbcPassword = "swordfish";
    
    private static final String CHECK_LOGIN  = "select " + "username, password " + "from users where " + "username = ? and password = ?;";
    
    public UserDAO() {
    	
    }
    
    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }
    
	private void closeConnection(Connection connection) {
		if (connection == null)
			return;
		try {
			connection.close();
		} catch (SQLException ex) {
		}
	}
	
	public User checkLogin(String username, String password)
	throws SQLException, ClassNotFoundException {
		
		User user = null;
		Connection connection = getConnection();
		
		System.out.println(CHECK_LOGIN);
		
        try {
        	PreparedStatement preparedStatement = connection.prepareStatement(CHECK_LOGIN);
        	
        	preparedStatement.setString(1, username);
        	preparedStatement.setString(2, password);
       	
        	ResultSet result = preparedStatement.executeQuery();
        	
        	if(result.next()) {
        		System.out.println("ping!");
        		user = new User(result.getString("username"));
        	}

        } catch (SQLException e) {
            printSQLException(e);
		} finally {
			closeConnection(connection);
		}
        
        return user;
	}
	
	
	
    private void printSQLException(SQLException ex) {
    	
        for (Throwable e: ex) {
        	
            if (e instanceof SQLException) {
            	
                e.printStackTrace(System.err);
                
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                
                Throwable t = ex.getCause();
                
                while (t != null) {
                	
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                    
                }
            }
        }
    }
}
