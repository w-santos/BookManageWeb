package com.bookmanage.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bookmanage.dao.BookDAO;
import com.bookmanage.model.Book;

@WebServlet("/")

public class BookServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private BookDAO bookDAO;
	
	public void init() {
		bookDAO = new BookDAO();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		doGet(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		
		String action = request.getServletPath();
		
		try {
			switch(action) {
			case "/new":
				System.out.println("Action Taken: " + action);
				showNewForm(request, response);
				break;
			case "/insert":
				System.out.println("Action Taken: " + action);
				insertBook(request, response);
				break;
			case "/delete":
				System.out.println("Action Taken: " + action);
				deleteBook(request, response);
				break;
			case "/edit":
				System.out.println("Action Taken: " + action);
				showEditForm(request, response);
				break;
			case "/update":
				System.out.println("Action Taken: " + action);
				updateBook(request, response);
				break;
			default:
				System.out.println("Action Taken: None/List");
				listBook(request, response);
				break;
			}
		} catch(SQLException ex) {
			throw new ServletException(ex);
		}
	}
	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	
        RequestDispatcher dispatcher = request.getRequestDispatcher("book-form.jsp");
        
        dispatcher.forward(request, response);
    }
    
    private void insertBook(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException {
        
        String book_title = request.getParameter("book_title");
        String author_name = request.getParameter("author_name");
        String genre = request.getParameter("genre");
        
        Book newBook = new Book(book_title, author_name, genre);
        
        bookDAO.insertBook(newBook);
        
        response.sendRedirect("list");
    }
    
    private void deleteBook(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException {
    	
        int id = Integer.parseInt(request.getParameter("id"));
        
        bookDAO.deleteBook(id);
        
        response.sendRedirect("list");

    }
    
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, ServletException, IOException {

    	int id = Integer.parseInt(request.getParameter("id"));
        Book existingBook = bookDAO.selectBook(id);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("book-form.jsp");
        
        request.setAttribute("book", existingBook);
        
        dispatcher.forward(request, response);

    }

	private void updateBook(HttpServletRequest request, HttpServletResponse response)
	throws SQLException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		String book_title = request.getParameter("book_title");
        String author_name = request.getParameter("author_name");
        String genre = request.getParameter("genre");
        
        Book book = new Book(id, book_title, author_name, genre);
        
        bookDAO.updateBook(book);

        response.sendRedirect("list");
		
	}

    private void listBook(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException, ServletException {
    	
        List<Book> listBook = bookDAO.selectAllBooks();
        
        request.setAttribute("listBook", listBook);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("book-list.jsp");
        
        dispatcher.forward(request, response);
    }
}
